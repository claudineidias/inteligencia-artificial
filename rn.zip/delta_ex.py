import numpy
import math


def f(u):
  return (2 / (1 + math.exp(-u)))-1


def findOutput(data, w):
    lamb = 1.0
    o = []
    for i in range(0, len(w)):
        u = 0
        for j in range(0, len(data)):
            u += w[i][j]*data[j]
        o.append(f(lamb * u))

    return o


# initialization
p = [[1,1,-1],[1,-1,-1],[-1,1,-1],[-1,-1,-1]]   # conjunto de valores de entrada ampliados com a entrada dummy
d = [[1],[1],[1],[-1]]   # saidas desejadas
w = []
for i in range(0, len(d[0])):
    w.append(numpy.random.rand(len(p[0])))          # inicializacao randomica dos pesos

c = 0.5          #taxa de aprendizado
d_error = 0.001   #erro desejado

iter = 0
while True:
    error = 0
    for i in range(0, len(p)):
        o = findOutput(p[i], w)

        for k in range (0, len(d[i])):
            error += 0.5*(d[i][k]-o[k])**2.0

        for k in range(0, len(d[i])):
            delta = (d[i][k] - o[k]) * (1 - o[k] * o[k]) / 2
            for j in range(0, len(p[0])):
                w[k][j] += c * delta * p[i][j]

    iter += 1
    print(error, " ##  ", w)
    if error < d_error:
        print('N. iterations:', iter)
        break
