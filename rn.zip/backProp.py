import numpy
import math


def f(u):
  return (2 / (1 + math.exp(-u)))-1


def findOutput(data, w):
    lamb = 1.0
    o = []
    for i in range(0, len(w)):
        u = 0
        for j in range(0, len(data)):
            u += w[i][j]*data[j]
        o.append(f(lamb * u))

    return o


# initialization
no = 2  # número de neurônios da camada oculta
p = [[1,1,-1],[1,-1,-1],[-1,1,-1],[-1,-1,-1]]   # conjunto de valores de entrada ampliados com a entrada dummy
d = [[-1],[1],[1],[-1]]   # saidas desejadas

v = []
dv = []
for i in range(0, no):
    v.append(numpy.random.rand(len(p[0])).tolist())          # inicializacao randomica dos pesos
    dv.append(numpy.zeros(len(p[0])).tolist())

w = []
dw = []
for i in range(0, len(d[0])):
    w.append(numpy.random.rand(no+1).tolist())          # inicializacao randomica dos pesos
    dw.append(numpy.zeros(no+1).tolist())  # inicializacao randomica dos pesos

c = 0.01         #taxa de aprendizado
d_error = 0.01   #erro desejado
mom = 0.7        #momentum

iter = 0
e_old = 0
while True:
    error = 0
    for i in range(0, len(p)):
        y = findOutput(p[i], v)
        o = findOutput(y, w)

        for k in range (0, len(d[i])):
            error += 0.5*(d[i][k]-o[k])**2.0

        do = []
        for k in range(0, len(d[i])):
            do.append((d[i][k] - o[k]) * (1 - o[k] * o[k]) / 2)
            for j in range(0, no):
                dw[k][j] = (1-mom)*c * do[k] * y[j] + mom*dw[k][j]
                w[k][j] += dw[k][j]

        for j in range(0, no):
            for k in range(0, len(d[i])):
                s = do[k]*w[k][j]
            dy = s * (1 - y[j] * y[j]) / 2
            for h in range(0, len(p[0])):
                dv[j][h] = (1-mom)*c * dy * p[i][h] + mom*dv[j][h]
                v[j][h] += mom*dv[j][h]

    iter += 1
    print(error, " ##  ", w)
    if error < d_error:
        print('N. iterations:', iter)
        break



# print result
